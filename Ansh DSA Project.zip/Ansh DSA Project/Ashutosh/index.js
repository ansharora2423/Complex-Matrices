function solveKnapsack() {
    window.location.href = 'Knapsack.html';
}

function solveCoinChange() {
    window.location.href = 'coinchange.html';
}

function generateFibonacci() {
    window.location.href = 'fibonnaci.html'
}

function multiplyMatrices() {
    window.location.href = 'Matrix.html'
}
document.getElementById("knapsackBtn").addEventListener("click", solveKnapsack);
document.getElementById("coinChangeBtn").addEventListener("click", solveCoinChange);
document.getElementById("fibonacciBtn").addEventListener("click", generateFibonacci);
document.getElementById("matrixChainBtn").addEventListener("click", multiplyMatrices);
